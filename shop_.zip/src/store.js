import { configureStore, createSlice} from '@reduxjs/toolkit'

let cart = createSlice({
    name : 'cart',
    initialState : [
        {id : 0, name : 'White and Black', count : 2},
        {id : 2, name : 'Grey Yordan', count : 1}
      ],
    reducers : {
        changeCount(state, action){
            let a = state.find( element => element.id == action.payload);
            a.count++
        },
        changeCart(state, action){
            let p = action.payload;
            let a = {id:p.id, name: p.title, count: 1}
            let matchp = state.find( element => element.id == action.payload.id);
            if( matchp ){
                matchp.count += 1;
            }else{
                state.push(a);
            }
            
        },
        deleteItem(state, action){
            let idx = state.findIndex( element => element.id == action.payload);
            state.splice(idx, 1)
        }
    }
})
export  let { changeCount, changeCart, deleteItem } = cart.actions

export default configureStore({
  reducer: { 
    cart : cart.reducer
  }
}) 