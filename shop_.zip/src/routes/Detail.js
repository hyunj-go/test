import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Nav } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { changeCart } from './../store.js'

function Detail(props) {

    let state = useSelector((state)=>{return state})
    let dispatch = useDispatch();
    let navigate = useNavigate();

    let {id} = useParams();
    let prd = props.shoes.find( element => element.id == id );
    let [alrt, setAlrt] = useState(true);
    let [num, setNum] = useState('');
    let [tab, setTab] = useState(0);
    let [fade, setFade] = useState('');

    //최근 본 상품
    useEffect(()=>{
        let output = localStorage.getItem('watched');
        output = JSON.parse(output);
        output.push(prd.id)
        output = new Set(output);
        // output = Array.from(output);
        localStorage.setItem('watched', JSON.stringify([...output]))
    })

    useEffect(()=>{
        let a = setTimeout(()=>{ setAlrt(false); },2000);
        
        return ()=>{
            clearTimeout(a)
        }
    }, [])

    useEffect(()=>{
        if(isNaN(num)){
            alert('숫자만 입력하세요');
        }
    }, [num])

    useEffect(()=>{
        setFade('open');
        return ()=>{
            setFade('')
        }
    }, [])

    return(
        <div className={'detail ' + fade}>
            <div className="container">
                {
                    alert == true
                    ? <div className="alert alert-warning">
                        2초이내 구매시 할인
                    </div>
                    : null
                }
                
                <div className="row">
                    <div className="col-md-6">
                        <img src={"https://codingapple1.github.io/shop/shoes"+ (prd.id+1) +".jpg"} width="100%" alt=""/>
                    </div>
                    <input onChange={(e)=>{
                        setNum(e.target.value)
                    }}/>
                    <div className="col-md-6">
                        <h4 className="pt-5">{prd.title}</h4>
                        <p>{prd.content}</p>
                        <p>{prd.price}</p>
                        <button className="btn btn-danger" onClick={()=>{ 
                            navigate('/cart');
                            dispatch(changeCart(prd)) 
                        }}>주문하기</button> 
                    </div>
                </div>
            </div> 

            <Nav variant="tabs"  defaultActiveKey="link0">
                <Nav.Item>
                    <Nav.Link onClick={() => { setTab(0) }} eventKey="link0">버튼0</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link onClick={() => { setTab(1) }} eventKey="link1">버튼1</Nav.Link>
                </Nav.Item>
                <Nav.Item>
                    <Nav.Link onClick={() => { setTab(2) }} eventKey="link2">버튼2</Nav.Link>
                </Nav.Item>
            </Nav>
            <TabContent tab={tab}/>
        </div>
    )    
}

function TabContent({tab}){

    let [fade, setFade] = useState('')
    useEffect(() => {
        let a = setTimeout(()=>{setFade('end')}, 100)
        return () => {
            clearTimeout(a)
            setFade('')
        }
    }, [tab])

    return (<div className={'start ' + fade}>
        { [<div>내용0</div>, <div>내용1</div>, <div>내용2</div>][tab] }
    </div>)
}


export default Detail;