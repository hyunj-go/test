import {Suspense, lazy, useEffect, useState} from "react"
import { Button, Navbar, Container, Nav } from 'react-bootstrap'
import './App.css'
import data from './data.js'
import { Routes, Route, Link, useNavigate, Outlet } from 'react-router-dom'
import axios from "axios"
// import Detail from './routes/Detail.js'
// import Cart from './routes/Cart.js'
const Detail = lazy(()=>import('./routes/Detail.js'));
const Cart = lazy(()=>import('./routes/Cart.js'));

function App() {

  let [shoes, setShoes] = useState(data);
  let navigate = useNavigate();
  let [cnt, setCnt] = useState(2);
  let [load, setLoad] = useState(false);

  //최근 본 상품 
  useEffect(()=>{
    if(!localStorage.getItem('watched')){
      localStorage.setItem('watched', JSON.stringify([]))
    }    
  },[])

  return (
    <div className="App">

      <Navbar className='nav'>
        <Container>
          <Navbar.Brand href="/">Goods Shop</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link onClick={ ()=>{ navigate('/') } } >Home</Nav.Link>
            {/* <Nav.Link onClick={ ()=>{ navigate('/detail')} }>Detail</Nav.Link> */}
          </Nav>
        </Container>
      </Navbar>
   
      <Suspense fallback={<div>로딩중임</div>}>
        <Routes>
          <Route path="/" element={
            <>
              <div className='main-bg'></div>
              <div className="watched" style={{position:'fixed', top:'100px', right:'0'}}>
                <p>최근 본 상품</p>
                {
                  JSON.parse(localStorage.getItem('watched')).map(function(a, i){
                    return(
                      <div key={i}>
                        <div>
                          <span>{shoes[a].title}</span>
                        </div>
                      </div>
                    )
                  })
                }
              </div>
              <div className='container'>
                {
                load ? <span style={{position:'fixed', top:'50%', left:'50%', transform:'translate(-50%,-50%)'}}>로드중</span> 
                : null
                }
                <div className='row'>
                  {
                    shoes.map(function(a, i){
                      return (
                        <Card shoes={shoes[i]} i={i} key={i}></Card>
                      )
                    })
                  }
                </div>
              </div>
              {
                <button onClick={() => {
                    if( cnt < 4 ){
                    setLoad(true);
                    axios.get('https://codingapple1.github.io/shop/data' + cnt + '.json')
                    .then((result)=>{ 
                        const newArray = [...shoes, ...result.data];
                        setShoes(newArray);console.log(newArray)
                        setCnt(cnt+1);console.log(cnt)
                        setLoad(false);
                    })
                    .catch(()=>{
                      console.log('오류')
                      setLoad(false);
                    })
                  }else {
                    alert('상품 없음')
                  }
                }}>더보기</button>
              }
            </>
          } />
          <Route path="/detail/:id" element={ <Detail shoes={shoes} /> } />
          <Route path="/cart" element={ <Cart/> } />

          <Route path="/about" element={ <About/> } >
            <Route path="member" element={ <div>멤버</div> } />
            <Route path="location" element={ <div>위치정보</div> } />
          </Route>

          <Route path="*" element={ <div>없는 페이지에요</div> } />
        </Routes>
      </Suspense>
    </div>
  );
}

function About() {
  return(
    <div>
      <h4>회사정보</h4>
      <Outlet></Outlet>
    </div>
  )
}

function EventPage(){
  return(
    <div>
      <h4>오늘의 이벤트</h4>
      <Outlet></Outlet>
    </div>
  )
}

function Card(props) {
  let navigate = useNavigate();
  return (
    <div className='col-md-4'>
      <div onClick={()=>{navigate('/detail/' + props.i)}}><img src={'https://codingapple1.github.io/shop/shoes'+ (props.shoes.id+1) +'.jpg'} width="80%"/></div>
      <h4>{props.shoes.title}</h4>
      <p>{props.shoes.content}</p>
    </div>
  )
}

export default App;
